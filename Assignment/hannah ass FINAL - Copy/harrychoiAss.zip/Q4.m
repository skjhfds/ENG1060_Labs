% Q4
% Name : Harry Choi
% ID   : 32464223
% Date Modified : 12-May-2021

fprintf('\n Q4\n===================================\n')

%Text description of your strategy
fprintf('My strategy is to spend the whole day at site 1, because it has the highest\nquantity of gold available.\n');

%Final summary
price=2276.5/31.1*final_recovered;
fprintf('The final gold takings would be %.2fg, which would be worth $%.2f.\n',final_recovered,price)
fprintf('This works out to be an hourly rate of $%.2f per hour.\n',price/4)
fprintf('\nI probably wouldn''t quit my job to mine in the Golden Triangle based on these numbers.\n\n')