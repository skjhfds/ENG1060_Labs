% run_all.m
clear all; close all; clc; fclose all;

%% do not modify any part of this file!
% it runs each part individually
% there should be no intervention from the user
% students will lose marks if this file does not run properly

%% Question 0
%Q0a
Q0a;

%% Question 1
%Q1a
Q1a;

%Q1b
Q1b;

%Q1c
Q1c;

%% Question 2
%Q2a
Q2a;

%Q2b
Q2b;

%% Question 3
%Q3a
Q3a;

%Q3b
Q3b;

%% Question 4
%Q4
Q4;